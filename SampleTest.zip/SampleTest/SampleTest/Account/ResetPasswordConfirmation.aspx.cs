﻿using System.Web.UI;

namespace SampleTest.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}